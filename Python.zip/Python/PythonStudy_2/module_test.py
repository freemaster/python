#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#함수 선언 -> 두개의정수를 더해주는 함수
def add(num1, num2) :
    return num1+num2

